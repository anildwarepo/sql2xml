SELECT
     COUNT(*) AS [Value]
FROM
     [virtualtables].[Rows] AS [Date_Time_Zone_spike]

WHERE [Date_Time_Zone_spike].[VirtualTable_Id] = 1